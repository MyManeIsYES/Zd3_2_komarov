﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd3
{
    class Passenger_cars : Car
    {
        int release_year;
        string color;
        double price;

        public int Release_year
        {
            get{return release_year;}
            set{release_year = value;}
        }
        public string Color
        {
            get{return color;}
            set{color = value;}
        }
        public double Price
        {
            get{return price;}
            set{price = value;}
        }
        public Passenger_cars (double mileage, double con_per_km) : base(mileage, con_per_km)
        {
            Mileage = mileage;
            Con_per_km = con_per_km;
        }
        public void Create (double mileage, double con_per_km, int release_year, string color, double price) 
        {
            Mileage = mileage;
            Con_per_km = con_per_km;
            this.release_year = release_year;
            this.color = color;
            this.price = price;
        }
        public void Create ( int release_year, string color, double price)
        {
            this.release_year = release_year;
            this.color = color;
            this.price = price;
        }
        public void Deletion ()
        {
            Mileage = 0;
            Con_per_km = 0;
            release_year = 0;
            color = "";
            price = 0;
        }
        public override double Q ()
        {
            return Mileage/Con_per_km*1.15*release_year;
        }
        public override string Info ()
        {
            return $"mileage: {Mileage};\ncon_per_km: {Con_per_km}\nrelease_year: {release_year}\ncolor: {color}\nprice: {price}";
        }
    }
}
