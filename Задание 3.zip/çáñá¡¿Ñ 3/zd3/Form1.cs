﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zd3
{
    public partial class Form1 :Form
    {
        Passenger_cars passenger_Cars;
        Dictionary<string, Passenger_cars> list;
        public Form1 ()
        {
            InitializeComponent( );
            list = new Dictionary<string, Passenger_cars>( );
            label6.Text = "";
            CreateButton.Enabled = true;
            RecreateButton.Enabled = false;
            ClearButton.Enabled = false;
            DeletionButton.Enabled = false;
            Deletion.Enabled = false;
        }

        private void CreateButton_Click (object sender, EventArgs e)
        {
            if ( textBox1.Text != "" )
            {
                passenger_Cars = new Passenger_cars((double) numericUpDown1.Value, (double) numericUpDown2.Value);
                passenger_Cars.Create((int) numericUpDown3.Value, textBox1.Text, (double) numericUpDown4.Value);
                label6.Text = passenger_Cars.Info( );
                CreateButton.Enabled = false;
                RecreateButton.Enabled = true;
                ClearButton.Enabled = true;
            }
            else
            {
                MessageBox.Show("Цвет не задан");
            }

        }

        private void RecreateButton_Click (object sender, EventArgs e)
        {
            if ( textBox1.Text != "" )
            {
                passenger_Cars.Create((double) numericUpDown1.Value, (double) numericUpDown2.Value, (int) numericUpDown3.Value, textBox1.Text, (double) numericUpDown4.Value);
                label6.Text = passenger_Cars.Info( );
            }
            else
            {
                MessageBox.Show("Цвет не задан");
            }
        }

        private void ClearButton_Click (object sender, EventArgs e)
        {
            passenger_Cars.Deletion( );
            label6.Text = passenger_Cars.Info( );
            DeletionButton.Enabled = true;
        }

        private void DeletionButton_Click (object sender, EventArgs e)
        {

            DialogResult dr = MessageBox.Show("Удалить?", "Удаление", MessageBoxButtons.YesNo);
            if ( dr == DialogResult.Yes )
            {
                passenger_Cars = null;
                CreateButton.Enabled = true;
                RecreateButton.Enabled = false;
                ClearButton.Enabled = false;
                DeletionButton.Enabled = false;
                label6.Text = "";
            }

        }
        private void Set_ListBox ()
        {
            listBox1.Items.Clear( );
            foreach (var v in list) 
            {
                listBox1.Items.Add(v.Key);
            }
        }
        private void Add_Click (object sender, EventArgs e)
        {
            if (passenger_Cars!=null)
            {
                if ( textBox2.Text != "" )
                {
                    bool b = true;
                    foreach ( var v in list )
                    {
                        if ( v.Key == textBox2.Text ) b = false;
                    }
                    if ( b )
                    {
                        Passenger_cars pc = new Passenger_cars( passenger_Cars.Mileage,passenger_Cars.Con_per_km);
                        pc.Create(passenger_Cars.Release_year,passenger_Cars.Color,passenger_Cars.Price);
                        list.Add(textBox2.Text, pc);
                        Set_ListBox( );
                        if ( list.Count( ) > 0 )
                        {
                            Deletion.Enabled = true;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Такой в списке уже есть");
                    }

                }
                else
                {
                    MessageBox.Show("Нет названия");
                }
            }
            else 
            {
                MessageBox.Show("Несоздан обьект");
            }

            
        }

        private void Deletion_Click (object sender, EventArgs e)
        {
            if ( textBox2.Text != "" )
            {
                bool b = false;
                foreach ( var v in list )
                {
                    if (v.Key==textBox2.Text)
                    {
                        b = true;
                        break;
                    }
                }
                if (b) 
                {
                    DialogResult dr = MessageBox.Show("Удалить из списка?", "Удаление", MessageBoxButtons.YesNo);
                    if ( dr == DialogResult.Yes )
                    {
                        list.Remove(textBox2.Text);
                    }
                    if ( list.Count( ) <= 0 )
                    {
                        Deletion.Enabled = false;
                    }
                    Set_ListBox( );
                }
                else
                {
                    MessageBox.Show("Нет такой машиный в списке");
                }
                
            }
            else
            {
                MessageBox.Show("Нет названия");
            }
        }

        private void listBox1_SelectedIndexChanged (object sender, EventArgs e)
        {
            int i = 0;
            foreach (var v in list)
            {
                if (i==listBox1.SelectedIndex) 
                {
                    passenger_Cars.Create(v.Value.Mileage,v.Value.Con_per_km,v.Value.Release_year,v.Value.Color,v.Value.Price);
                    textBox2.Text = v.Key;
                    break;
                }
                i++;
            }
            label6.Text = passenger_Cars.Info( );
            
        }
    }
}
